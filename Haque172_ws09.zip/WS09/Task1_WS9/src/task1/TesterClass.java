package task1;

/*
 * Md Mehedi Haque
 * 154908172
 * WS09 task1
 * */
import java.util.HashSet;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.stage.Stage;

public class TesterClass extends Application {

	int num1 = (int) (10 * Math.random()) + 1;
	int num2 = (int) (10 * Math.random()) + 1;

	String randomNum = num1 + " and " + num2;

	HashSet<String> answers = new HashSet<String>();
	public QuizApp window = new QuizApp();

	@Override
	public void start(Stage primaryStage) {

		// Append the fields with the random numbers.
		setNumbers();

		// Event Handlers
		window.additionField.setOnKeyReleased(e -> {
			if (e.getCode() == KeyCode.ENTER) {
				eval();
			}
		});

		window.subtractionField.setOnKeyReleased(e -> {
			if (e.getCode() == KeyCode.ENTER) {
				eval();
			}
		});

		window.multipleField.setOnKeyReleased(e -> {
			if (e.getCode() == KeyCode.ENTER) {
				eval();
			}
		});

		window.divisonField.setOnKeyReleased(e -> {
			if (e.getCode() == KeyCode.ENTER) {
				eval();
			}
		});

		window.tryField.setOnKeyReleased(e -> {
			if (e.getCode() == KeyCode.ENTER) {
				{
					if (window.tryAggainText.getText().equalsIgnoreCase("y")) {
						TesterClass app = new TesterClass();
						app.start(primaryStage);
					}
				}
			}
		});

		// Setting title to the stage
		primaryStage.setTitle("Quiz Application");

		// Creating a scene object
		Scene scene = new Scene(window.root, 500, 400);

		// Adding scene to the stage
		primaryStage.setScene(scene);

		// Displaying the contents of the stage
		primaryStage.show();
	}

	public void eval() {
		int add = num1 + num2;
		int sub = num1 - num2;
		int mul = num1 * num2;
		double div = ((double) num1 / (double) num2);

		// counters
		int correctCount = 0;
		int wrongCount = 0;

		// user input
		int userAdd = Integer.parseInt(window.additionField.getText());
		int userSub = Integer.parseInt(window.subtractionField.getText());
		int userMul = Integer.parseInt(window.multipleField.getText());
		double userDiv = Integer.parseInt(window.divisonField.getText());

		// addition
		if (userAdd == add) {
			correctCount++;
		} else {
			wrongCount++;
		}
		// subtraction
		if (userSub == sub) {
			correctCount++;
		} else {
			wrongCount++;
		}
		// multiplication
		if (userMul == mul) {
			correctCount++;
		} else {
			wrongCount++;
		}
		// division
		if (userDiv == div) {
			correctCount++;
		} else {
			wrongCount++;
		}

		window.correctAnsText.setText(String.valueOf(correctCount));
		window.wrongAnsText.setText(String.valueOf(wrongCount));

		if (!answers.contains(window.additionField.getText())) {
			answers.add(window.additionField.getText());
		} else {
			window.alreadyAnsText.setText("You already answered this, try a different answer.");
		}

		if (!answers.contains(window.subtractionField.getText())) {
			answers.add(window.subtractionField.getText());
		} else {
			window.alreadyAnsText.setText("You already answered this, try a different answer.");
		}

		if (!answers.contains(window.multipleField.getText())) {
			answers.add(window.multipleField.getText());
		} else {
			window.alreadyAnsText.setText("You already answered this, try a different answer.");
		}

		if (!answers.contains(window.divisonField.getText())) {
			answers.add(window.divisonField.getText());
		} else {
			window.alreadyAnsText.setText("You already answered this, try a different answer.");
		}

		System.out.println(answers);

	}

	public void setNumbers() {
		window.randomText.setText(randomNum);
		window.additionText.setText(window.additionText.getText() + randomNum + ":");
		window.subtractionText.setText(window.subtractionText.getText() + randomNum + ":");
		window.multipleText.setText(window.multipleText.getText() + randomNum + ":");
		window.divisionText.setText(window.divisionText.getText() + randomNum + ":");
	}

	public static void main(String[] args) {
		launch(args);
	}

}
