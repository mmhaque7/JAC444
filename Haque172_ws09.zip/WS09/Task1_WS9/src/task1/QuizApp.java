package task1;

/*
 * Md Mehedi Haque
 * 154908172
 * WS09 task1
 * */
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

public class QuizApp extends BorderPane {
	// grid pane
	GridPane root = new GridPane();
	GridPane randomPane = new GridPane();
	GridPane resultPane = new GridPane();
	GridPane tryPane = new GridPane();

	// labels
	Text introText = new Text("Two randomly generated numbers are: ");
	Text randomText = new Text("");
	Text additionText = new Text("What is the addition of ");
	Text subtractionText = new Text("What is the subtraction of ");
	Text multipleText = new Text("What is multiplication of ");
	Text divisionText = new Text("What is division of ");
	Text correcText = new Text("Number of Correct Answers: ");
	Text correctAnsText = new Text("");
	Text worngText = new Text("Number of Wrong Answers: ");
	Text wrongAnsText = new Text("");
	Text alreadyAnsText = new Text("");
	Text tryAggainText = new Text("Would you like to try with two other different numbers?");

	// fields
	TextField additionField = new TextField();
	TextField subtractionField = new TextField();
	TextField multipleField = new TextField();
	TextField divisonField = new TextField();
	TextField tryField = new TextField();

	public void create() {
		// padding
		root.setPadding(new Insets(8, 8, 8, 8));
		randomPane.setPadding(new Insets(8, 8, 8, 8));
		resultPane.setPadding(new Insets(8, 8, 8, 8));
		tryPane.setPadding(new Insets(8, 8, 8, 8));

		// gaps
		randomPane.setVgap(4);
		randomPane.setHgap(4);

		resultPane.setVgap(4);
		resultPane.setHgap(4);

		tryPane.setVgap(4);
		tryPane.setHgap(4);

		// Alignment
		root.setAlignment(Pos.TOP_CENTER);
		randomPane.setAlignment(Pos.TOP_CENTER);
		resultPane.setAlignment(Pos.TOP_CENTER);

		GridPane.setHalignment(additionText, HPos.RIGHT);
		GridPane.setHalignment(subtractionText, HPos.RIGHT);
		GridPane.setHalignment(multipleText, HPos.RIGHT);
		GridPane.setHalignment(divisionText, HPos.RIGHT);
		GridPane.setHalignment(correcText, HPos.RIGHT);
		GridPane.setHalignment(worngText, HPos.RIGHT);

		// fixing the nodes in the grid
		randomPane.add(introText, 1, 1);
		randomPane.add(randomText, 2, 1);

		root.add(randomPane, 1, 1);

		resultPane.add(additionText, 1, 1);
		resultPane.add(additionField, 2, 1);

		resultPane.add(subtractionText, 1, 2);
		resultPane.add(subtractionField, 2, 2);

		resultPane.add(multipleText, 1, 3);
		resultPane.add(multipleField, 2, 3);

		resultPane.add(divisionText, 1, 4);
		resultPane.add(divisonField, 2, 4);

		resultPane.add(correcText, 1, 5);
		resultPane.add(correctAnsText, 2, 5);

		resultPane.add(worngText, 1, 6);
		resultPane.add(wrongAnsText, 2, 6);

		root.add(resultPane, 1, 2);

		tryPane.add(alreadyAnsText, 1, 1);
		tryPane.add(tryAggainText, 1, 2);
		tryPane.add(tryField, 2, 2);
		tryPane.setPrefWidth(50);

		root.add(tryPane, 1, 3);

	}

	public QuizApp() {
		create();
	}
}
