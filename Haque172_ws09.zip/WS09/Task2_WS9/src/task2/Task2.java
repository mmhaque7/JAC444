package task2;

/*
 * Md Mehedi Haque
 * 154908172
 * WS09task2
 * 
 * */
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Task2 {
	public static void main(String[] args) {
		Map<String, String> capitalMap = new HashMap<String, String>();

		for (String[] countryCapital : capitals) {
			capitalMap.put(countryCapital[0], countryCapital[1]);
		}

		Scanner input = new Scanner(System.in);

		System.out.println("Please enter a country: ");
		String userCountry = input.nextLine();

		capitalMap.forEach((country, city) -> {
			if (userCountry.equalsIgnoreCase(country)) {
				System.out.println("The capital of " + country + " is " + city + ".");
			}
		});

	}

	private static String[][] capitals = { { "Canada", "Ottawa" }, { "Jamaica", "Kingston" }, { "Qatar", "Doha" },
			{ "Fiji", "Suva" }, { "Argentina", "Buenos Aires" },

			{ "Philippines", "Manila" }, { "Bangladesh", "Dhaka" }, { "South Korea", "Seoul" }, { "Peru", "Lima" },
			{ "England", "London" },

			{ "Turkey", "Ankara" }, { "Thailand", "Bangkok" }, { "Vietnam", "Hanoi" }, { "Japan", "Tokyo" },
			{ "Russia", "Moscow" },

			{ "England", "London" }, { "Peru", "Lima" }, { "Portugal", "Lisbon" }, { "Oman", "Muscat" },
			{ "Ethiopia", "Addis Ababa" },

			{ "Singapore", "Singapore" }, { "Lebanon", "Beirut" }, { "Nepal", "Kathmandu" },
			{ "Panama", "Panama City" }, { "Yemen", "Sana'a" }

	};
}
