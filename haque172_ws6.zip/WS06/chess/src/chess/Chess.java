package chess;

/*
 * 
 * Md Mehedi Haque
 * ws 06
 * 
 * */
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class Chess extends Application {
	@Override
	public void start(Stage priStage) {
		// creating the pane
		Pane root = new Pane();
		// create the grid
		Rectangle board = new Rectangle(5, 5, 400, 400);
		board.setFill(Color.BLACK);
		root.getChildren().add(board);

		for (int r = 0; r < 8; r++) {
			for (int c = 0; c < 8; c++) {
				// fill every other square as white
				if (r % 2 == c % 2) {
					Rectangle tile = new Rectangle((5 + c * 50), (5 + r * 50), 50, 50);
					tile.setFill(Color.WHITE);
					root.getChildren().add(tile);
				}
			}
		}

		// Setting the title
		priStage.setTitle("Chess Board");

		// Creating a scene object
		Scene scene = new Scene(root, 410, 410, Color.GREEN);

		// Adding scene to the stage
		priStage.setScene(scene);

		// Displaying the contents of the stage
		priStage.show();

	}

	public static void main(String[] args) {
		launch(args);
	}
}