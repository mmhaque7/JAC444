package task1;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

/*
 * Md Mehedi Haque
 * 154908172
 * WS08
 * 
 * */
public class BirthName extends BorderPane {
	// grid panes
	GridPane root = new GridPane();
	GridPane buttonPane = new GridPane();
	GridPane fieldPane = new GridPane();
	GridPane resultPane = new GridPane();

	// the labels
	Text yearText = new Text("Enter the Year: ");
	Text genderText = new Text("Enter Gender: ");
	Text nameText = new Text("Enter the Name: ");
	Text displayText = new Text("");

	// text fields
	TextField yearField = new TextField();
	TextField genField = new TextField();
	TextField nameField = new TextField();

	// buttons
	Button submitButton = new Button("Submit Query");
	Button exitButton = new Button("Exit");

	public BirthName() {
		// TODO Auto-generated constructor stub
		create();
	}

	public void create() {
		//
		root.setGridLinesVisible(false);
		buttonPane.setGridLinesVisible(false);
		resultPane.setGridLinesVisible(false);
		fieldPane.setGridLinesVisible(false);

		// size of buttons
		submitButton.setPrefWidth(100);
		exitButton.setPrefWidth(100);

		// padding on the grid
		root.setPadding(new Insets(10, 10, 10, 10));
		buttonPane.setPadding(new Insets(10, 10, 10, 10));
		fieldPane.setPadding(new Insets(10, 10, 10, 10));
		resultPane.setPadding(new Insets(10, 10, 10, 10));

		// Setting the gap between cells
		buttonPane.setHgap(15);
		fieldPane.setVgap(5);
		fieldPane.setHgap(5);

		// grid Alligment
		root.setAlignment(Pos.TOP_CENTER);
		fieldPane.setAlignment(Pos.TOP_CENTER);
		buttonPane.setAlignment(Pos.TOP_CENTER);
		resultPane.setAlignment(Pos.TOP_CENTER);

		fieldPane.add(yearText, 1, 1);
		fieldPane.add(yearField, 2, 1, 2, 1);
		fieldPane.add(genderText, 1, 3);
		fieldPane.add(genField, 2, 3, 2, 1);
		fieldPane.add(nameText, 1, 5);
		fieldPane.add(nameField, 2, 5, 2, 1);

		root.add(fieldPane, 1, 1);

		resultPane.add(displayText, 1, 1);

		root.add(resultPane, 1, 2);

		buttonPane.add(submitButton, 1, 1);
		buttonPane.add(exitButton, 2, 1);

		root.add(buttonPane, 1, 3);
	}

}
