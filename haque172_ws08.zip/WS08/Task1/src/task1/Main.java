package task1;

/*
 * Md Mehedi Haque
 * 154908172
 * WS08
 * 
 * */
import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
	public BirthName window = new BirthName();
	public static final String PATH = "babynamesranking";

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		window.submitButton.setOnAction(e -> {
			try {
				submit();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
		window.exitButton.setOnAction(e -> {
			System.exit(1);
		});
		// Setting title to the stage
		primaryStage.setTitle("Search Name Ranking Application");

		// Creating a scene object
		Scene scene = new Scene(window.root, 300, 250);

		// Adding scene to the stage
		primaryStage.setScene(scene);

		// Displaying the contents of the stage
		primaryStage.show();

	}

	public void submit() throws IOException {
		String year = window.yearField.getText();
		File file = new File(PATH + year + ".txt");

		// check whether the file exists
		if (!file.exists()) {
			window.displayText.setText("No Records are found in folowing year: " + year);
		}
		int rank = 0;
		Scanner input = new Scanner(file);

		while (input.hasNext()) {
			String readLine = input.nextLine();
			String[] splitFields = readLine.split(" ");
			// If gender is male and name matches within fields, get ranking.
			if (window.genField.getText().equalsIgnoreCase("M")
					&& splitFields[1].contains(window.nameField.getText())) {
				rank = Integer.parseInt(splitFields[0]);
			}
			// Else, find match within female fields.
			else if (splitFields[2].contains(window.nameField.getText())) {
				rank = Integer.parseInt(splitFields[0]);
			}
		}

		String gender;
		if (window.genField.getText().equalsIgnoreCase("M")) {
			gender = "Boy";
		} else {
			gender = "Girl";
		}
		if (rank != 0) {
			window.displayText.setText(
					gender + " name " + window.nameField.getText() + " is ranked #" + rank + " in " + year + " year");
		} else {
			window.displayText.setText("The name " + window.nameField.getText() + " is not found in the year " + year);
		}

	}

	public void build(String[] args) {
		launch(args);
	}

}
