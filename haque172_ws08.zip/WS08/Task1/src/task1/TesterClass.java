package task1;

import javafx.application.Application;

/*
 * Md Mehedi Haque
 * 154908172
 * WS08
 * 
 * */
public abstract class TesterClass extends Application {
	public static void main(String[] args) {
		Main x = new Main();
		x.build(args);
	}
}
