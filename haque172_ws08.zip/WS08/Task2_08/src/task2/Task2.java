package task2;

/*
 * Md Mehedi Haque
 * 154908172
 * WS08
 * 
 * */
import java.util.Scanner;

public class Task2 {

	@FunctionalInterface
	public interface ArrayProcessor {
		double apply(double[] array);
	}

	// maxium
	public static final ArrayProcessor MAX_ARRAY_PROCESSOR = array -> {
		double max = array[0];
		for (int i = 0; i < array.length; i++) {
			if (array[i] > max) {
				max = array[i];
			}
		}
		return max;
	};
	// find the minimum value in an array
	public static final ArrayProcessor MIN_ARRAY_PROCESSOR = array -> {
		double min = array[0];
		for (int i = 0; i < array.length; i++) {
			if (array[i] < min)
				min = array[i];
		}
		return min;
	};
	// find the sum of the values in the array
	public static final ArrayProcessor SUM_ARRAY_PROCESSOR = array -> {
		double total = 0;
		for (int i = 0; i < array.length; i++) {
			total += array[i];
		}
		return total;
	};
	// find the average of the values in the array.
	public static final ArrayProcessor AVG_ARRAY_PROCESSOR = array -> SUM_ARRAY_PROCESSOR.apply(array) / array.length;

	// counter
	public static ArrayProcessor counter(double value) {
		return array -> {
			int count = 0;
			for (int i = 0; i < array.length; i++) {
				if (array[i] == value)
					count++;
			}
			return count;
		};
	}

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("Please enter the length of the array: ");

		int length = input.nextInt();
		double[] myArray = new double[length];

		System.out.println("Please enter the elements of the array: ");

		for (int i = 0; i < length; i++) {
			myArray[i] = input.nextInt();
		}

		System.out.println("Please enter the value you want to check in array: ");
		int value = input.nextInt();

		System.out.println("Minimum of array: " + MIN_ARRAY_PROCESSOR.apply(myArray));
		System.out.println("Maximum of array: " + MIN_ARRAY_PROCESSOR.apply(myArray));
		System.out.println("Sum of array: " + SUM_ARRAY_PROCESSOR.apply(myArray));
		System.out.println("Average of array: " + AVG_ARRAY_PROCESSOR.apply(myArray));
		System.out.println("Number of " + value + "'s in the array: " + counter(value).apply(myArray));

		input.close();

	}
}
