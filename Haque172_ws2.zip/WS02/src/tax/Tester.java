/*
 * Md Mehedi Haque
 * WS02
 * 154908172
 * 
 * 
 * */
package tax;

import java.util.Scanner;

public class Tester {
	public static void main(String[] args) {

		// tax rates for 2001
		double[] rates01 = { .15, .275, .305, .355, .391 };

		// tax brackets for 2001
		int[][] bracket01 = {
				// single filers
				{ 27050, 65550, 136750, 297350, Integer.MAX_VALUE },
				// Married || widow
				{ 45200, 109250, 166500, 297350, Integer.MAX_VALUE },
				// Married Filing Separately
				{ 22600, 54625, 83250, 148675, Integer.MAX_VALUE },
				// head of house hold
				{ 36250, 93650, 151650, 297350, Integer.MAX_VALUE } };

		Tax tax2001 = new Tax(0, bracket01, rates01, Integer.MAX_VALUE);
		// Tax tax2009 = new Tax(0, bracket09, rates09, 50000);
		Tax tax2009 = new Tax();

		int selection = 0;
		String newLine = System.getProperty("line.separator");

		Scanner myObjScanner = new Scanner(System.in);
		System.out.println("Menu (Press 1 2 or 3)");

		System.out.println("1. Compute personal income tax" + newLine
				+ "2. Print the tax tables for taxable incomes (with range)" + newLine + "3. Exit");
		selection = myObjScanner.nextInt();

		switch (selection) {
		case 1:
			Tax computeTax = new Tax();
			int status;

			double taxIncome;
			System.out.println(newLine + "0 - single filer" + newLine + "1 - married jointly or qualifying widow(er)"
					+ newLine + "2 - married separately" + newLine + "3 - head of household)");
			System.out.println("Enter the filing status: ");
			status = myObjScanner.nextInt();
			computeTax.setFilingStatus(status);
			System.out.println("Enter the Taxable Income: ");
			taxIncome = myObjScanner.nextDouble();
			computeTax.setTaxableIncome(taxIncome);
			// System.out.println(computeTax.getTaxableIncome());

			computeTax = new Tax(status, tax2009.getBrackets(), tax2009.getRates(), taxIncome);
			System.out.println("Tax is: " + computeTax.getTax());
			break;
		case 2:
			int interval = 1000;

			System.out.println(newLine);
			System.out.println("Enter the amount From: ");
			int from = myObjScanner.nextInt();
			System.out.println("Enter the amount to: ");
			int to = myObjScanner.nextInt();
			System.out.println("2001 tax tables for taxable income from $50,000 to $60,000");
			print(tax2001, from, to, interval);

			System.out.println(newLine);
			System.out.println(newLine);
			System.out.println("Enter the amount From: ");
			int from1 = myObjScanner.nextInt();
			System.out.println("Enter the amount to: ");
			int to1 = myObjScanner.nextInt();
			System.out.println("2009 tax tables for taxable income from $50,000 to $60,000");

			print(tax2009, from, to, interval);
			break;

		case 3:
			System.out.println("GoodBye");
			return;
		}

	}

	public static void print(Tax tax, double from, double to, double interval) {
		// Print header
		System.out.println("---------------------------------------------------------------------\n"
				+ "Taxable       Single      Married Joint       Married        Head of\n"
				+ "Income                    or Qualifying       Separate       a House\n"
				+ "                          Widow(er)\n"
				+ "---------------------------------------------------------------------");
		// Print Data
		for (double taxableIncome = from; taxableIncome <= to; taxableIncome += interval) {
			tax.setTaxableIncome(taxableIncome);
			System.out.printf("%-13.0f", taxableIncome);
			tax.setFilingStatus(tax.SINGLE_FILER);
			System.out.printf("%6.2f", tax.getTax());
			tax.setFilingStatus(tax.MARRIED_JOINTLY_OR_QUALIFYING_WIDOWER);

			System.out.printf("%13.2f", tax.getTax());
			tax.setFilingStatus(tax.MARRIED_SEPARATELY);
			System.out.printf("%15.2f", tax.getTax());
			tax.setFilingStatus(tax.HEAD_OF_HOUSEHOLD);
			System.out.printf("%14.2f\n", tax.getTax());
			;
		}
	}
}
