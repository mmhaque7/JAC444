/*
 * Md Mehedi Haque
 * WS02
 * 154908172
 * 
 * 
 * */
package tax;

// Implement Tax class
public class Tax {
	// Data fields
	private int filingStatus;
	public static final int SINGLE_FILER = 0;
	public static final int MARRIED_JOINTLY_OR_QUALIFYING_WIDOWER = 1;
	public static final int MARRIED_SEPARATELY = 2;
	public static final int HEAD_OF_HOUSEHOLD = 3;
	private int[][] brackets;
	private double[] rates;
	private double taxableIncome;

	// Construct a tax object with default
	// filingStatus, rates, brackets and taxableIncome
	Tax() {
		// Defalut filing status
		filingStatus = SINGLE_FILER;

		// Defalut tax rates
		double[] currentRates = { .10, .15, .25, .28, .33, .35 };
		;
		setRates(currentRates);

		// Default brackets for each rate for all the filing statuses
		int[][] currBracket = { { 8350, 33950, 82250, 171550, 372950 }, { 16700, 67900, 137050, 20885, 372950 },
				{ 8350, 33950, 68525, 104425, 186475 }, { 11950, 45500, 117450, 190200, 372950 } };
		setBrackets(currBracket);

		// Default taxable income
		taxableIncome = 0;

	}

	// Construct a tax object with specified
	// filingStatus, rates, brackets and taxableIncome
	Tax(int filingStatus, int[][] brackets, double[] rates, double taxableIncome) {
		setFilingStatus(filingStatus);
		setBrackets(brackets);
		setRates(rates);
		setTaxableIncome(taxableIncome);
	}

	/** Set a new filingStatus */
	public void setFilingStatus(int filingStatus) {
		this.filingStatus = filingStatus;
	}

	/** Return filingStatus */
	public int getFilingStatus() {
		return filingStatus;
	}

	/** set new brackets */
	public void setBrackets(int[][] brackets) {
		this.brackets = brackets;
	}

	/** Return brackets */
	public int[][] getBrackets() {
		return brackets;
	}

	/** Set new rates */
	public void setRates(double[] rates) {
		this.rates = rates;
	}

	/** Return rates */
	public double[] getRates() {
		return rates;
	}

	/** Set new taxableIncome */
	public void setTaxableIncome(double taxableIncome) {
		this.taxableIncome = taxableIncome;
	}

	public double getTax() {
		double tax = 0;

		// tax in the first bracket
		if (taxableIncome <= brackets[filingStatus][0])
			return tax = taxableIncome * rates[0];
		else
			tax = brackets[filingStatus][0] * rates[0];

		// tax in the possible 2nd, 3rd, 4th, and 5th brackets
		for (int i = 1; i < brackets[0].length; i++) {
			if (taxableIncome > brackets[filingStatus][i])
				tax += (brackets[filingStatus][i] - brackets[filingStatus][i - 1]) * rates[i];

			else {
				tax += (taxableIncome - brackets[filingStatus][i - 1]) * rates[i];
				break;
			}
		}
		int j = 0;
		// tax in the possible last bracket
		if (j == brackets[0].length && taxableIncome > brackets[filingStatus][j - 1])
			tax += (taxableIncome - brackets[filingStatus][j - 1]) * rates[j];

		return tax;
	}
}