package phoneNum;

/*
 * Md Mehedi Haque
 * 154908172
 * WS05
 * */
import java.io.IOException;

public class Tester {
	public static void main(String[] args) throws IOException {
		Phone phone = new Phone();
		phone.getInput();
	}
}
