package task2;

/*
 * Md Mehedi Haque
 * 154908172
 * WS05
 * */
import java.io.IOException;

public class Tester {
	public static void main(String[] args) throws IOException {
		Letter letter = new Letter();
		letter.getText();
	}
}
