package task2;

/*
 * Md Mehedi Haque
 * 154908172
 * WS05
 * */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Letter {
	// all the alphabet including uppercase and lowercase

	char alphabet[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S',
			'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
			'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };

	int[] count = new int[alphabet.length];

	public void getText() throws IOException {
		System.out.println("File Name: ");
		Scanner input = new Scanner(System.in);
		String fileName = input.nextLine();

		File file = new File(fileName + ".txt");

		if (!file.exists()) {
			System.err.println("File does not exist");
			System.exit(0);

		}
		BufferedReader br = new BufferedReader(new FileReader(file));
		int i = 0;
		do {
			// loops through each letter, i the letter in stream matches the alphabet then
			// we increment the count
			for (int j = 0; j < alphabet.length; j++) {
				char ch = (char) i;
				if (alphabet[j] == ch) {
					count[j]++;
				}
			}
		} while ((i = br.read()) != -1);// eof
		for (int j = 0; j < alphabet.length; j++) {
			System.out.print("Number of " + alphabet[j] + "\'s: " + count[j] + "\n");
		}
		br.close();
		input.close();
	}

}
