package thread;

public class ThreadTest {
	public static void main(String[] args) {
		ReverseThread thread = new ReverseThread();
		thread.start();
	}
}
