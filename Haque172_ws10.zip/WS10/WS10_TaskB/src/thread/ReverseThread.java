package thread;

/*
 * Md Mehedi Haque
 * 154908172
 * ws10 b
 * */
class ReverseThread extends Thread {
	static int numOfThread = 50;

	public void run() {

		try {
			ReverseThread.numOfThread--;
			if (ReverseThread.numOfThread < 0) {
				return;
			}
			make();
			System.out.println("Hello from <" + this.getName() + ">");
		} catch (InterruptedException e) {
		}
	}

	public void make() throws InterruptedException {
		ReverseThread t = new ReverseThread();
		t.start();

		t.join();
	}
}