module ws10_TaskB {
}