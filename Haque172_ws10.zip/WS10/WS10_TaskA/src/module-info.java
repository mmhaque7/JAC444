module wsS10_TaskA {
}