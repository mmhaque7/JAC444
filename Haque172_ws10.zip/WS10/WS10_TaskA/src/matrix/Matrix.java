package matrix;
/*
 * Md Mehedi Haque
 * WS10
 * 154908172
 * 
 * */

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;

public class Matrix {

	public static void main(String[] args) {
		int size = 2000;
		double[][] a = new double[size][size];
		double[][] b = new double[size][size];
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < b[i].length; j++) {
				a[i][j] = Math.random();
				b[i][j] = Math.random();
			}
		}
		long time = System.currentTimeMillis();
		parallelAddMatrix(a, b);
		System.out.println("------TASK 1------");
		System.out.println((System.currentTimeMillis() - time) + " millisecond - parallelAddMatrix()");
		time = System.currentTimeMillis();
		addMatrix(a, b);
		System.out.println((System.currentTimeMillis() - time) + " millisecond - addMatrix()");
	}

	public static double[][] parallelAddMatrix(double[][] a, double[][] b) {
		double[][] c = new double[a.length][a.length];

		RecursiveAction mainTask = new AddMatrix(a, b, c, 0, a.length, 0, a.length);
		ForkJoinPool pool = new ForkJoinPool();
		pool.invoke(mainTask);
		return c;
	}

	public static double[][] addMatrix(double[][] a, double[][] b) {
		double[][] result = new double[a.length][a[0].length];
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				result[i][j] = a[i][j] + b[i][j];
			}
		}
		return result;
	}
}
