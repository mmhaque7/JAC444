package taskA;

import java.util.Scanner;

/*
 * Md Mehedi Haque
 * 154908172
 * Workshop1
 * Jan, 22 2020
 * 
 * */

public class Task1 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the number of rows and columns in the array: ");
		int row = in.nextInt();
		int column = in.nextInt();
		// System.out.println(row + " " + column);

		double usrrArr[][] = new double[row][column];
		System.out.println("Enter the Array");
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < column; j++) {
				usrrArr[i][j] = in.nextDouble();
			}
		}
		int[] loc = largestElem(usrrArr);
		System.out.println("The location of the largest element is " + loc[0] + " " + loc[1]);
		// System.out.println("The max is:" + usrrArr[0][1]);
	}

	public static int[] largestElem(double[][] a) {
		double max = a[0][0];
		int[] loc = new int[] { 0, 0 };

		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				if (max < a[i][j]) {
					max = a[i][j];
					loc[0] = i;
					loc[1] = j;
				}
			}
		}
		return loc;
	}

}
