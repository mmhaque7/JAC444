package TaskB;

/*
 * Md Mehedi Haque
 * 154908172
 * WS01-Task-2
 * 
 * 
 * 
 * */
public class tester {
	public static void main(String[] args) {
		// create objects for two die
		die d1 = new die();
		die d2 = new die();
		// create variables that will hold the rolled die number.
		int roll1 = d1.roll();
		int roll2 = d2.roll();
		// roll1 = 2;
		// roll2 = 1;

		// sum of the two rolls
		int sumRoll = roll1 + roll2;

		// roll the dice
		System.out.println("You rolled " + roll1 + " + " + roll2 + " = " + sumRoll);

		// win condition (rolled 7 or 11)
		if (sumRoll == 7 || sumRoll == 11) {
			System.out.println("Congratulations, You win");
		}
		// loss condition (rolled 2 3 12)
		else if (sumRoll == 2 || sumRoll == 3 || sumRoll == 12) {
			System.out.println("Better Luck Next Time, You lose");
		}
		// keep rolling to win or lose
		else {
			int point = sumRoll;
			boolean playAgain = true;

			do {
				roll1 = d1.roll();
				roll2 = d2.roll();
				// roll1 = 2;
				// roll2 = 1;
				sumRoll = roll1 + roll2;

				;
				// roll the dice agian
				System.out.println("You rolled " + roll1 + " + " + roll2 + " = " + sumRoll);
				if (sumRoll == point) {
					System.out.println("Congratulations, You win");
					playAgain = false;
				} else if (sumRoll == 7) {
					System.out.println("Better Luck Next Time, You lose");
					playAgain = false;
				}
			} while (playAgain);
		}
	}

}
