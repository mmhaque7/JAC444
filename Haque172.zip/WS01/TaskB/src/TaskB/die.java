package TaskB;

/*
 * Md Mehedi Haque
 * 154908172
 * WS01-Task-2
 * 
 * 
 * 
 * 
 */
public class die {
	private static int dieRoll;

	public die() {
		dieRoll = 0;
	}

	public static int roll() {
		dieRoll = (int) (Math.random() * 6) + 1;
		return dieRoll;

	}

	/*
	 * public static void main(String[] args) { System.out.println(roll());
	 * System.out.println(roll()); System.out.println(roll());
	 * System.out.println(roll()); System.out.println(roll());
	 * System.out.println(roll()); }
	 */
}
