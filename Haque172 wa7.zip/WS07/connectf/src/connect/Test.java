package connect;

public class Test {
	public static void main(String[] args) {
		Connect game = new Connect();
		// Flag.
		boolean loop = true;
		String[][] grid = game.createGrid();
		int playerTurn = 0;

		System.out.println("Welcome to Connect Four!\n");
		game.printGrid(grid);

		while (loop) {
			if (playerTurn % 2 == 0) {
				game.redTurn(grid);
			} else {
				game.yellowTurn(grid);
			}

			playerTurn++;

			// Reprint returned grid on console.
			game.printGrid(grid);

			// Check for win condition after each turn.
			if (game.checkWin(grid) != "no win") {
				if (game.checkWin(grid) == "R") {
					System.out.println("The red player has won.");
				} else if (game.checkWin(grid) == "Y") {
					System.out.println("The yellow player has won.");
				}

				// End the game when winner is determined.
				loop = false;
			}
		}

	}
}
